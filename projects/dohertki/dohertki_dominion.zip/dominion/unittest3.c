//unittest3.c
#include "dominion.h"
#include "dominion_helpers.h"
#include "rngs.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>


struct gameState state_chk ={
        2,                    //Number of players
        {10,8,8,8,46,40,30},  //suplyCount[curse,estate,duchy,province,]
        {0,0}, //embargoTokens
        0,     //outpostPlayed
        0,     //Oupost Turn
        0,     // whoseTurn;
        0,     //int phase;
        1,     //int numActions; * Starts at 1 each turn */
        0,     //int coins; * Use as you see fit! */
        0,     //int numBuys; * Starts at 1 each turn */
        {{0,1,2},{4,5,6}},    //hand[MAX_PLAYERS][MAX_HAND];
        {0,0},  // handCount[MAX_PLAYERS];
        {{0,1,2,3,4,5,6,7,10,25},{0,1,2,3,4,5,6,7,10,25}},    //deck[MAX_PLAYERS][MAX_DECK];
        {10,10},              //deckCount[MAX_PLAYERS];
        {{0,0},{1,0}},    //discard[MAX_PLAYERS][MAX_DECK];
        {0},    //discardCount[MAX_PLAYERS];
        {0},    // playedCards[MAX_DECK];
         0     // playedCardCount;
    };

int main(){
  int turn;

  turn = whoseTurn(&state_chk);
 
 if(turn == 0){
    printf("SUCCESS: The correct player is one\n");

  }else{
    printf("FAILED: The player is not q but %d\n", turn +1 );
  }


  state_chk.whoseTurn = 1;

  turn = whoseTurn(&state_chk);



  if(turn == 1){
    printf("SUCCESS: The correct player is two\n");

  }else{
    printf("FAILED: The player is not 2 but %d\n", turn +1 );
  }



  return 0;
}

